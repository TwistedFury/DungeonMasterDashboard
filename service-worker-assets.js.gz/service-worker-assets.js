self.assetsManifest = {
  "version": "7k2u7gXG",
  "assets": [
    {
      "hash": "sha256-nkZxVuCrGfnFb6rE8R3IvOh9Lt1Yx1g60khfAXZud10=",
      "url": "DungeonMasterDashboard.styles.css"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-nHMXUsTyP4CPsVNjhRsaeZGBy2FY22JTRCMbfYmtm/s=",
      "url": "_framework/DungeonMasterDashboard.k0l0iwdeze.wasm"
    },
    {
      "hash": "sha256-IN5hrX0mFJ3VMQllVS3NDFeGvETQ3EnCUbK4MW3/DlI=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.4b9ra4izmy.wasm"
    },
    {
      "hash": "sha256-m1FCF3uP2gKUZPiidn1jz6MgomFWCVx2/ttvbQIt1F0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.h17fhz4ubu.wasm"
    },
    {
      "hash": "sha256-InNVlfHXAMjGIBqwwd92NJdJGoGRaEV49jHpRtNZrxg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.u4j47johqt.wasm"
    },
    {
      "hash": "sha256-0KnNt1hX9O+9AysSpXv8aTbodOn+LVNwOTmN3MnUjjM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.08dhhycrby.wasm"
    },
    {
      "hash": "sha256-mI1UWXOYyDCEr6AmTWkOdUpT7kySl2NshyoYHBSYaUY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.gajjq0rm7v.wasm"
    },
    {
      "hash": "sha256-rplJs0MdrthZoA8irI69c/77zsOI/b7QBV4We9S1PLo=",
      "url": "_framework/Microsoft.AspNetCore.Components.q99zw41ft4.wasm"
    },
    {
      "hash": "sha256-BCB3DlLFocowiTdicYNuqtjVw2/oFfEO5a5sRF7/zH8=",
      "url": "_framework/Microsoft.AspNetCore.Identity.EntityFrameworkCore.48u4e49nba.wasm"
    },
    {
      "hash": "sha256-hyVhdjUpyHZZbSg8L54mTM1ZMzP8qbsRT1GFPfuKAW4=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.3tj1rw598p.wasm"
    },
    {
      "hash": "sha256-bsW0Dyz3MEMOsF9hGPzAUvNz3yXOL1xemo/IA9Di5qg=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Abstractions.at5ws5d15p.wasm"
    },
    {
      "hash": "sha256-QgTD9p8f7aqSec22y+GLt5lgVxeOOt35KMlYPqEqm80=",
      "url": "_framework/Microsoft.EntityFrameworkCore.Relational.yz3eomkul5.wasm"
    },
    {
      "hash": "sha256-hTt0yQ/Go6SNNik73nVgI+lBBLmPYq74zo7mPau/Uzk=",
      "url": "_framework/Microsoft.EntityFrameworkCore.bwrd2pn530.wasm"
    },
    {
      "hash": "sha256-Vo0zFoymG+e4bWMY1QNq14VMyBd4Rw8Y/Dyb02u4FXs=",
      "url": "_framework/Microsoft.Extensions.Caching.Abstractions.61k1rbde39.wasm"
    },
    {
      "hash": "sha256-xDwh00zgQRhnGcVhcf12/i85N0Lq4JAC0AZ0M8ow0R0=",
      "url": "_framework/Microsoft.Extensions.Caching.Memory.wxwsns8np7.wasm"
    },
    {
      "hash": "sha256-yo4mXQQl/ydl7MB6Mv1BgbHLGRM8LU9qFvGn4/+0fiM=",
      "url": "_framework/Microsoft.Extensions.Configuration.2ighdhd1um.wasm"
    },
    {
      "hash": "sha256-upBN5/bJpuCbmjE3Ho9YTBJ/WBDkgo59rnWE5M6/flc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6o6eit7sus.wasm"
    },
    {
      "hash": "sha256-FPs1VityJ6jXLVw3FgdaCH5MAGeiZX8CR18RjrZHnWk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.wnpgblskiw.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-V4HGOjALFymPzBJznWGGehjhjnlKGkX9cZsF3Ajt7LA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.pw5nlvfgj7.wasm"
    },
    {
      "hash": "sha256-xlf1UGMAYKP1APqGJdAvI31cwENOfV9XPIfFv0gIV44=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uvwb5aebge.wasm"
    },
    {
      "hash": "sha256-oIu8yLUtJP4EGU5Om1fDSAzpY3ffMjl9rKZnwII0XTs=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.47qgfhx9eb.wasm"
    },
    {
      "hash": "sha256-npldTut68mqzQngvA3K/GSRCbYWhEVEjs1SJ18ArUuo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.isypqwhob8.wasm"
    },
    {
      "hash": "sha256-b0m8Wel1E9QpDC7hEq9aW+IuBmFN6Ed4EWUXYVgtgW0=",
      "url": "_framework/Microsoft.Extensions.Identity.Core.fsvmjjucso.wasm"
    },
    {
      "hash": "sha256-kGaMx+3c/IVo0mix5TdF7549A+xJrb/BRD8isaRUNmY=",
      "url": "_framework/Microsoft.Extensions.Identity.Stores.g8yxzuoac8.wasm"
    },
    {
      "hash": "sha256-+mnVtk+FNffVAOO4pCOiEQY0UNI43woTGrIZxJZv+OI=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.q7bxnensfm.wasm"
    },
    {
      "hash": "sha256-pNkyTWP87OlJ7b2sqEnmR7I1h0ge/BovZYt5q1eKVoc=",
      "url": "_framework/Microsoft.Extensions.Logging.ovzkrv1s8s.wasm"
    },
    {
      "hash": "sha256-pyWsUcPd3YLorRQE70Uke2ADx3z5FztEUqfU+lnWTo4=",
      "url": "_framework/Microsoft.Extensions.Options.9w9x65j0r5.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-LflsX5/lCKu5OnIeW2ybJ8WnCYONPG6qlURpO5T/y5c=",
      "url": "_framework/Microsoft.JSInterop.38vzmiamit.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-bEjUDkLJLhpxSUpgpQlU6WfSSHhufIg2zZuSN1jbQyU=",
      "url": "_framework/System.Collections.Concurrent.otof5mat32.wasm"
    },
    {
      "hash": "sha256-vs3T2MnnQDhqt4jZ2h9O0yr1Aw2H7Uo0b+1RHP8SL18=",
      "url": "_framework/System.Collections.Immutable.yvwx5p80dz.wasm"
    },
    {
      "hash": "sha256-oDJz3Bp4wVNCLqhcA13LszPpFOuin7pNcI7u9PhkD88=",
      "url": "_framework/System.Collections.NonGeneric.4n6c6g4x8f.wasm"
    },
    {
      "hash": "sha256-5yWaSrBIXuLi/Ba9ou8Mm4wZaWMe46IyoBQYZBnI0Ww=",
      "url": "_framework/System.Collections.Specialized.1y5ggmv9ra.wasm"
    },
    {
      "hash": "sha256-YmZvtdByfSQYJMWaQ8FzMsiwGy3sZ/ZuNfNou99dYW8=",
      "url": "_framework/System.Collections.u94jialjni.wasm"
    },
    {
      "hash": "sha256-+jXv5myZK7RDL3jISNBm3YS6BnYzTHWqFyv/ULjOWrc=",
      "url": "_framework/System.ComponentModel.6p3x58af60.wasm"
    },
    {
      "hash": "sha256-bFj+754QpbiRaBrYT0FfWOPYvNgax/PwKkVdwT4S2xA=",
      "url": "_framework/System.ComponentModel.Annotations.ci4z2h0i86.wasm"
    },
    {
      "hash": "sha256-skdCdsSWrDmpondIECzvIosF9ALkI+X8BOMwnfqoO2U=",
      "url": "_framework/System.ComponentModel.Primitives.6qqcafgb78.wasm"
    },
    {
      "hash": "sha256-jh/ibXHc+dKQYGeWOxAOTOoHCvj3NZnfCoQtwuAbwds=",
      "url": "_framework/System.ComponentModel.TypeConverter.uh76dy0m1m.wasm"
    },
    {
      "hash": "sha256-SO0fymkfk1+D0WbpDBcUN0Y0UblGNA0NeO5CBcIDwLo=",
      "url": "_framework/System.Console.0e0v768hk2.wasm"
    },
    {
      "hash": "sha256-vDUBdYrT7OKIUK8IjSnr8nMPNIddGxc/9vQjH5RF2kk=",
      "url": "_framework/System.Data.Common.0llwd6lt9e.wasm"
    },
    {
      "hash": "sha256-u1bRoliVstVUXFB9M4ZHaUWyHFimKajobfNXk/Q2x7E=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.3uczvrabje.wasm"
    },
    {
      "hash": "sha256-TzJC+vry4ufab/a77aXZ0Fgow9PQCkj+jIzENyQdu9k=",
      "url": "_framework/System.Diagnostics.Tracing.lv40lg0hrn.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-rmlgWG3gWrKX1ieLk8BWMpAaDMXQOAhRCYv0LSCArXU=",
      "url": "_framework/System.Linq.Expressions.mzlwnev4qs.wasm"
    },
    {
      "hash": "sha256-RSF6b2FxNUxnq0jqHG1IcPrSJLFTWW4ZVSNXTLSjyzI=",
      "url": "_framework/System.Linq.Queryable.l4mhnkdyn3.wasm"
    },
    {
      "hash": "sha256-BukDgxjLNkCWCFiO7cK+VPuGvGCrbrh2qB+n3TvIovo=",
      "url": "_framework/System.Linq.urhwtusvnq.wasm"
    },
    {
      "hash": "sha256-WPNo+uzZTZsFnIYXX4qAiQDkV5uoU5cT3FYIhUfh48w=",
      "url": "_framework/System.Memory.4ppxvduxmr.wasm"
    },
    {
      "hash": "sha256-X6golN/AMKSC7GH+wRCHObEyUMVMRKjj1cGRVULVMlU=",
      "url": "_framework/System.Net.Http.Json.5vghsfrk65.wasm"
    },
    {
      "hash": "sha256-Gr65ZUmbT+tXGkhgRJ/ETwWgfsCKdgf/PFCuRnnsR8M=",
      "url": "_framework/System.Net.Http.urvtcf9bhj.wasm"
    },
    {
      "hash": "sha256-6KQbSvMtOKq+Ef9S9S0n818GTjUHIFthe5q18EEUMdQ=",
      "url": "_framework/System.Net.NetworkInformation.o0oe6hw5ux.wasm"
    },
    {
      "hash": "sha256-B1slAaLukC6bz1yAZ31/DRRpQTLlxOMmCNC31ltm02g=",
      "url": "_framework/System.Net.Primitives.h2iuyz6bul.wasm"
    },
    {
      "hash": "sha256-yv86g8ALFG7DvHbwQSRr7ZLxEWTvZkKcW+Pn8kMbHPw=",
      "url": "_framework/System.ObjectModel.ihk6zofcba.wasm"
    },
    {
      "hash": "sha256-oanu7w0bfyIiLjebcF3GDyjTCqfbGSex5WX+a3h0kZY=",
      "url": "_framework/System.Private.CoreLib.1o01gg2mi4.wasm"
    },
    {
      "hash": "sha256-LTGbS1cvDkW+QPKv5DmUS/hVtLb9WF3At4VC6uhrQUs=",
      "url": "_framework/System.Private.Uri.be99rbryiq.wasm"
    },
    {
      "hash": "sha256-K/CCP9xoK6yHuxt3cM0QlADKnG6BRsYOl16WM+SmJLw=",
      "url": "_framework/System.Private.Xml.xxd9h4mbsx.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-9aPqmfsBq57giPJV0U0WNFiu3KZ9vUmwqO4JNEcQ880=",
      "url": "_framework/System.Runtime.InteropServices.fj9jdecnpc.wasm"
    },
    {
      "hash": "sha256-s6pkPrG48aD6Nza6Fwd5BGktn7xAYfdhymhSvi+Y5+c=",
      "url": "_framework/System.Runtime.Numerics.h31r31tvyc.wasm"
    },
    {
      "hash": "sha256-ypTiliDO+K94K9tx5JJqceJzqkR+fec+0WQ2pEXtyJ0=",
      "url": "_framework/System.Runtime.yyq1itrvvw.wasm"
    },
    {
      "hash": "sha256-MrXmmcDETzGcoCqy747firFPEQFJPD8FsVQridrccgs=",
      "url": "_framework/System.Security.Claims.egwev4e3w3.wasm"
    },
    {
      "hash": "sha256-oAiqN4+0rXCP07gQh1D89o9s9TjaMTh1Pgbtm7wEiPg=",
      "url": "_framework/System.Security.Cryptography.ouxcxoa0xa.wasm"
    },
    {
      "hash": "sha256-TxCM6CAY3QTgmWkSpAR3BrxhZtDaG/qm6nYNQZedzhw=",
      "url": "_framework/System.Text.Encodings.Web.1gnwx0z74m.wasm"
    },
    {
      "hash": "sha256-eay/VJQcHkQfXQER44MSnBG4sf4iRN0S4mAB8BP9Obw=",
      "url": "_framework/System.Text.Json.9ki6hypovk.wasm"
    },
    {
      "hash": "sha256-a10L5hrmL7RT3Kkeeo3EnXTgv8nSqywq3Bicv27/Tw4=",
      "url": "_framework/System.Text.RegularExpressions.n9ddpsnvjk.wasm"
    },
    {
      "hash": "sha256-Xu1MO/TRKm5JZD+Olqo1Dj4GUKspXXZtgQZgIlDYLhE=",
      "url": "_framework/System.Threading.Thread.yr31wp0wmo.wasm"
    },
    {
      "hash": "sha256-+k4DuxOEgYIx3YeCr7qySA+Yp3B5lv6XLE2YIb0p8X8=",
      "url": "_framework/System.Threading.qcbqzs6xd6.wasm"
    },
    {
      "hash": "sha256-1oqdAd+bWTIM0rhILZQyVT1WeOJtsFk/P0/SuCiuOXU=",
      "url": "_framework/System.Transactions.Local.mg06vdva30.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-tjie09uavTiX1TnkP9OL+OcnxCOs44ff5Dgws1rnAnc=",
      "url": "_framework/dotnet.native.2mv1pqdd2n.wasm"
    },
    {
      "hash": "sha256-JvdIvkSF0x6euoPT2QnQSMg2Gyv2oJbFeBi1XmWLYFU=",
      "url": "_framework/dotnet.native.69poregybn.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-qp2NhE2XRl3jvGMGqOQc+UTTm5O1uURd53f6h8cuOrk=",
      "url": "_framework/dotnet.yl4k62w4yy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-G5Ga+uCOkVHxSiBJsnj1MOcAOxo5GUbq6mFEUmBp5nQ=",
      "url": "appsettings.Development.json"
    },
    {
      "hash": "sha256-USVdUvMV7pxDoeghNrXQfKvlh5eiJw+4E/GtnX7MSYY=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-CsChHlHUYGbuIEdR+5X9lxWNazWkgwxEsDPWRPQmRpQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-5G+JRbT71TdcQE8Kyvo/FDHx5zBdiOwUV/PBYB2mtKo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-bd/hHbGBmAB15BSSQajhiy7F6AJOPK+4EZ1CM6+bf/M=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-7nMI3V4zsBwSkJFQY7ZwU8wRVsX+W0giLD6fPLEZ5nM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-whJcbep4HEhXZ6p5kPDVSLUBkl78bdF9+XF5EAqN0x4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-DKAoXq2B5/+GES/vbZQzCFjeMfJ2S9DMelXKDE5oI5g=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-sVQ+nujhEWkazyBQ0P/KR64LFNZ0GJwO0UR2gHLkoW4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-2Id8tGSCut11DZCJSW63SqDGIvq1Z6AqRquAk/5/5G8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-oNTOhm4ZIAlXz6oZX2uIjDAegWTwlpQ7Tdy5JSjreP8=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-TZgtD8RczrZXgSskFmLdSIq5MpEmINVgR2IRpS1csdc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-A1HqMj5Hhqpq5dWAVyt3tqerp5rO7NGAJp9qRSATopI=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-5+DbNDUhd9MW+y47NbMhmPlJxNUd8BlE8tqJ8uQBW/c=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
